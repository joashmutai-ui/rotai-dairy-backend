# Rotai Dairy Backend

Simple Node.js + Express backend for Rotai Dairy Tracker.

## How to upload to GitHub (web UI)

1. Go to https://github.com/new and create a new repository:
   - Repository name: `rotai-dairy-backend`
   - Visibility: Public
   - Do not initialize with README (we'll upload files)

2. After creating, on the repository page click **Add file → Upload files**, then drag & drop
   the contents of this ZIP (all files) and commit.

## How to deploy to Railway

1. Go to https://railway.app/new and click "Deploy from GitHub".
2. Choose your `rotai-dairy-backend` repository and authorize Railway to access it.
3. Railway will detect Node.js and set the start command automatically.
4. In your Railway project, add the **PostgreSQL** plugin.
5. Open the PostgreSQL plugin's SQL editor and run the `init.sql` file to create tables and seed cows.
6. Deploy. Railway will run `npm start` and provide a public URL.

## Endpoints

- GET /api/cows
- POST /api/cows { name }
- GET /api/production?date=YYYY-MM-DD
- POST /api/production { cow_id, date, milk_kg }
- GET /api/sales
- POST /api/sales { date, total_milk, price_per_kg, buyer, paid }
- GET /api/expenses
- POST /api/expenses { date, category, amount, notes }
- GET /api/staff
- POST /api/staff { name, role, salary }
- GET /api/payroll
- POST /api/payroll { staff_id, date, amount, paid }
