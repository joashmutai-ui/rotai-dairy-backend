-- init.sql: create tables and seed initial cows
CREATE TABLE IF NOT EXISTS cows (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS productions (
  id SERIAL PRIMARY KEY,
  cow_id INT REFERENCES cows(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  milk_kg NUMERIC(10,2) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sales (
  id SERIAL PRIMARY KEY,
  date DATE NOT NULL,
  total_milk NUMERIC(12,2),
  price_per_kg NUMERIC(10,2),
  total_value NUMERIC(14,2),
  buyer VARCHAR(200),
  paid BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS expenses (
  id SERIAL PRIMARY KEY,
  date DATE NOT NULL,
  category VARCHAR(100) NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS staff (
  id SERIAL PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  role VARCHAR(100),
  salary NUMERIC(12,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payroll (
  id SERIAL PRIMARY KEY,
  staff_id INT REFERENCES staff(id) ON DELETE SET NULL,
  date DATE NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  paid BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- seed cows
INSERT INTO cows (name) VALUES
('SNOW'),
('BLACK BERRY'),
('RED'),
('MANDELA'),
('LAILA')
ON CONFLICT DO NOTHING;
