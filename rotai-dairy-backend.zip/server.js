// Rotai Dairy Tracker API (simple GitHub-ready version)
// Uses process.env.PORT for Railway automatic port
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

// Health
app.get('/', (req, res) => res.json({ ok: true, service: 'Rotai Dairy Tracker API' }));

// Cows
app.get('/api/cows', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM cows ORDER BY id');
  res.json(rows);
});

app.post('/api/cows', async (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: 'name required' });
  const { rows } = await pool.query('INSERT INTO cows(name) VALUES($1) RETURNING *', [name]);
  res.status(201).json(rows[0]);
});

// Production
app.get('/api/production', async (req, res) => {
  const { date } = req.query;
  let q = 'SELECT p.*, c.name as cow_name FROM productions p JOIN cows c ON c.id = p.cow_id';
  const params = [];
  if (date) { q += ' WHERE p.date = $1'; params.push(date); }
  q += ' ORDER BY p.date DESC, p.id DESC';
  const { rows } = await pool.query(q, params);
  res.json(rows);
});

app.post('/api/production', async (req, res) => {
  const { cow_id, date, milk_kg } = req.body;
  if (!cow_id || !date || milk_kg == null) return res.status(400).json({ error: 'cow_id, date, milk_kg required' });
  const { rows } = await pool.query('INSERT INTO productions(cow_id, date, milk_kg) VALUES($1,$2,$3) RETURNING *', [cow_id, date, milk_kg]);
  res.status(201).json(rows[0]);
});

// Sales
app.get('/api/sales', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM sales ORDER BY date DESC, id DESC');
  res.json(rows);
});

app.post('/api/sales', async (req, res) => {
  const { date, total_milk, price_per_kg, buyer, paid } = req.body;
  if (!date || total_milk == null || price_per_kg == null) return res.status(400).json({ error: 'date, total_milk, price_per_kg required' });
  const total_value = Number(total_milk) * Number(price_per_kg);
  const { rows } = await pool.query('INSERT INTO sales(date, total_milk, price_per_kg, total_value, buyer, paid) VALUES($1,$2,$3,$4,$5,$6) RETURNING *', [date, total_milk, price_per_kg, total_value, buyer || null, paid == null ? true : paid]);
  res.status(201).json(rows[0]);
});

// Expenses
app.get('/api/expenses', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM expenses ORDER BY date DESC, id DESC');
  res.json(rows);
});

app.post('/api/expenses', async (req, res) => {
  const { date, category, amount, notes } = req.body;
  if (!date || !category || amount == null) return res.status(400).json({ error: 'date, category, amount required' });
  const { rows } = await pool.query('INSERT INTO expenses(date, category, amount, notes) VALUES($1,$2,$3,$4) RETURNING *', [date, category, amount, notes || null]);
  res.status(201).json(rows[0]);
});

// Staff & Payroll
app.get('/api/staff', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM staff ORDER BY id');
  res.json(rows);
});

app.post('/api/staff', async (req, res) => {
  const { name, role, salary } = req.body;
  if (!name || !role) return res.status(400).json({ error: 'name and role required' });
  const { rows } = await pool.query('INSERT INTO staff(name, role, salary) VALUES($1,$2,$3) RETURNING *', [name, role, salary || 0]);
  res.status(201).json(rows[0]);
});

app.get('/api/payroll', async (req, res) => {
  const { rows } = await pool.query('SELECT p.*, s.name as staff_name FROM payroll p LEFT JOIN staff s ON s.id = p.staff_id ORDER BY p.date DESC, p.id DESC');
  res.json(rows);
});

app.post('/api/payroll', async (req, res) => {
  const { staff_id, date, amount, paid } = req.body;
  if (!staff_id || !date || amount == null) return res.status(400).json({ error: 'staff_id, date, amount required' });
  const { rows } = await pool.query('INSERT INTO payroll(staff_id, date, amount, paid) VALUES($1,$2,$3,$4) RETURNING *', [staff_id, date, amount, paid == null ? true : paid]);
  res.status(201).json(rows[0]);
});

// Simple report: production summary
app.get('/api/reports/production-summary', async (req, res) => {
  const { from, to } = req.query;
  let q = 'SELECT date, SUM(milk_kg) AS total_milk FROM productions';
  const params = [];
  if (from && to) { q += ' WHERE date BETWEEN $1 AND $2'; params.push(from, to); }
  q += ' GROUP BY date ORDER BY date DESC';
  const { rows } = await pool.query(q, params);
  res.json(rows);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('Server listening on port', PORT));
